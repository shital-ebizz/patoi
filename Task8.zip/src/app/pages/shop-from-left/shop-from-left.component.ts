import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-from-left',
  templateUrl: './shop-from-left.component.html',
  styleUrls: ['./shop-from-left.component.css']
})
export class ShopFromLeftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
