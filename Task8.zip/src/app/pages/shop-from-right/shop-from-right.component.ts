import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-from-right',
  templateUrl: './shop-from-right.component.html',
  styleUrls: ['./shop-from-right.component.css']
})
export class ShopFromRightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
