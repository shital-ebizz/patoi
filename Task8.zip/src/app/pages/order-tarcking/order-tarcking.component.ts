import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-tarcking',
  templateUrl: './order-tarcking.component.html',
  styleUrls: ['./order-tarcking.component.css']
})
export class OrderTarckingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
