import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/_service/cart.service';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: {
    id: number, product: string, image: string, price: number, quantity: number
  }[] = []

  isProductDetail: any = [];
  items: any = [];
  cartData: any;
  public wish: any;

  constructor(public cartservice: CartService, private modalService: NgbModal) { }

  ngOnInit(): void {
    this.cartservice.loadCart();
    this.items = this.cartservice.getItems();

    this.products = [
      {
        "id": 1,
        "product": "Pet brash",
        "image": "assets/img/products/products1.jpg",
        "price": 35,
        "quantity": 1
      },
      {
        "id": 2,
        "product": "Automatic dog blue leash",
        "image": "assets/img/products/products2.jpg",
        "price": 75,
        "quantity": 1
      },
      {
        "id": 3,
        "product": "Automatic dog blue leash",
        "image": "assets/img/products/products3.jpg",
        "price": 49,
        "quantity": 1
      },
      {
        "id": 4,
        "product": "Bowl with rubber toy",
        "image": "assets/img/products/products4.jpg",
        "price": 60,
        "quantity": 1
      },
      {
        "id": 5,
        "product": "Stack pet collars",
        "image": "assets/img/products/products5.jpg",
        "price": 90,
        "quantity": 1
      },
      {
        "id": 6,
        "product": "Dog toy",
        "image": "assets/img/products/products6.jpg",
        "price": 15,
        "quantity": 1
      },
      {
        "id": 7,
        "product": "Plastic muzzle",
        "image": "assets/img/products/products7.jpg",
        "price": 29,
        "quantity": 1
      },
      {
        "id": 8,
        "product": "Pet toy",
        "image": "assets/img/products/products8.jpg",
        "price": 25,
        "quantity": 1
      },
      {
        "id": 9,
        "product": "Pet chair",
        "image": "assets/img/products/products9.jpg",
        "price": 150,
        "quantity": 1
      },
      {
        "id": 10,
        "product": "Pink ceramic cat bowl",
        "image": "assets/img/products/products10.jpg",
        "price": 39,
        "quantity": 1
      },
      {
        "id": 11,
        "product": "Red dog bed",
        "image": "assets/img/products/products11.jpg",
        "price": 125,
        "quantity": 1
      },
      {
        "id": 12,
        "product": "Pet carrier",
        "image": "assets/img/products/products12.jpg",
        "price": 39,
        "quantity": 1
      },
    ]
  }

  openDetailProduct(data: any, content: any) {
    // console.log(data, 'sddssd')
    this.isProductDetail = data;
    this.modalService.open(content,
      { windowClass: 'productsQuickView', centered: true })
  }


  AddQty(isProductDetail: any) {
    this.cartservice.AddQty(isProductDetail);
    //console.log(isProductDetail.quantity);
  }

  minusQty(isProductDetail: any) {
    if (this.isProductDetail.quantity > 0)
      this.cartservice.minusQty(isProductDetail);
    // console.log(this.isProductDetail.quantity)
  }

  addToCart(item: any) {

    //console.log("product-quamtity", this.isProductDetail.quantity, item);

    if (!this.cartservice.itemInCart(item)) {
      // console.log('dfdfd')
      item.quantity = this.isProductDetail.quantity;
      // console.log("item.quantity", item.quantity)
      this.cartservice.addTocart(item);
      this.items = [...this.cartservice.getItems()];
      this.cartservice.saveCart('product_details', this.items);

    } else {
      console.log('ddddddddddd')

    }
  }

  addToWishlist(item: any) {
    debugger
    if (!this.cartservice.itemInCart(item)) {
      this.cartservice.AddTowish(item);
      //console.log(item, 'wishlist');
      this.wish = [...this.cartservice.getItems()];
      this.cartservice.wishlist_product("wishlist_product", item);
      console.log(item)
    }
  }



}

