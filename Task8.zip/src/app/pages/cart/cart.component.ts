import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/_service/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  public cart_product: any;
  items: any = [];

  constructor(public cartservice: CartService) { }

  ngOnInit() {
    this.cart_product = this.cartservice.getData;
  }


  removeFromCart(item: any) {
    debugger
    //   this.cartservice.removeItem(item);
    //   this.items = this.cartservice.getItems();

  }

}
