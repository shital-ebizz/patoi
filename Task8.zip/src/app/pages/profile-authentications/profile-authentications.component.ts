import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-authentications',
  templateUrl: './profile-authentications.component.html',
  styleUrls: ['./profile-authentications.component.css']
})
export class ProfileAuthenticationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
