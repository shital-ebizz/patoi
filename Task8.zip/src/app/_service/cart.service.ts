import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class CartService {
  item: any = [];
  items: any = [];
  quantity: any = 1;
  public cartData: any;
  public isProductDetail: any;
  products: {
    id: number, product: string, image: string, price: number, quantity: number
  }[] = []


  constructor() { }

  ngOnInit(): void {

  }

  AddQty(isProductDetail: any) {
    isProductDetail.quantity++;
    //console.log(isProductDetail)
  }

  minusQty(isProductDetail: any) {
    isProductDetail.quantity--;
    //console.log(isProductDetail);
  }

  addTocart(data: any) {

    this.items.push(data);

    let existingItems: any = [];

    if (localStorage.getItem('product_details')) {
      existingItems = this.getCartDetails;

      existingItems = [data, ...existingItems];
      console.log('Item Exist')
    }
    else {
      console.log('No item Exist');
      existingItems = [data]
    }
    // console.log(existingItems, 'kkkkkkkkkkkkkkkkkkkkkkk', this.items)
    this.saveCart('product_details', this.items);
  }

  AddTowish(data: any) {
    this.item.push(data);
    let existingItems: any = [];
    if (localStorage.getItem('wishlist_product')) {
      existingItems = this.getCartDetails;
      existingItems = [data, ...existingItems];
      console.log('Already item exit in wishlist')
    }
    else {
      console.log('No item exit in wishlist');
      existingItems = [data];
    }
    console.log(existingItems, 'Item Exist ');
    this.wishlist_product("wishlist_product", this.item)
  }

  public getData(key: any) {
    let data = localStorage.getItem(key) || "";
    // return this.StorageService.decrypt(data);

    return data;
  }

  get getCartDetails() {
    return this.getData('product_details') != null && this.getData('product_details') != '' ? JSON.parse(this.getData('product_details')) : [];
  }

  loadCart() {
    this.items = this.getCartDetails;
  }

  wishlist_product(key: any, item: any) {
    localStorage.setItem("wishlist_product", JSON.stringify(item))
    console.log(item, 'data')

  }
  saveCart(key: any, items: any) {
    // var str = this.StorageService.encrypt(JSON.stringify(items))
    var str = JSON.stringify(items)
    localStorage.setItem(key, str)
    console.log(str, 'str')
    return str;
  }

  addQty() {
    this.isProductDetail.quantity++;
    console.log(this.isProductDetail.quantity);
  }

  getItems() {
    console.log(this.items, 'qqqqqqqqqq')
    return this.items;
  }
  getWishlist() { }

  itemInCart(cartData: any) {
    return this.items.findIndex((o: any) => o.id === cartData.id) > -1;
  }

  // removeItem(item: any) {
  //   const index = this.items.findIndex((o: { id: any; }) => o.id === item.id)
  //   if (index > -1) {
  //     this.items.splice(index, 1)
  //     this.saveCart();
  //   }
  // }
}
